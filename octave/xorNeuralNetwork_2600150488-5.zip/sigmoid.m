function output = sigmoid(x)

% sigmoid active function

output =1./(1+exp(-x));
end